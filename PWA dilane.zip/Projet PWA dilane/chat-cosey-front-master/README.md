Ce projet a été démarré avec [Create React App].

## Scripts disponibles

Dans le répertoire du projet, vous pouvez exécuter :

### `npm start`

Exécute l'application en mode développement.<br />
Ouvrez [http://localhost:3000](http://localhost:3000) pour l'afficher dans le navigateur.

La page se rechargera si vous apportez des modifications.<br />
Vous verrez également toutes les erreurs de charpie dans la console.

### `test npm`

Lance le testeur en mode montre interactive.<br />
Voir la section sur [l'exécution de tests](https://facebook.github.io/create-react-app/docs/running-tests) pour plus d'informations.

### `npm run build`

Génère l'application pour la production dans le dossier "build".<br />
Il regroupe correctement React en mode production et optimise la construction pour les meilleures performances.




